The _intermediate_ folder should contain saved Python objects and intermediate
data that are used in the project's modeling pipeline, e.g.:
- MySVM.pkl
- ModelTfidfTransformer.pkl
- transformed_dataset.csv
