The _data_ folder should contain any project files related to _original_ source data. This may include:
- Data files, such as .csv and .json
- SQL queries
- Other files related to connecting to data sources
